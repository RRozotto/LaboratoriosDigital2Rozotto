/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdint.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint8_t ContadorA;
uint8_t ContadorB;
uint8_t modo;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  HAL_GPIO_TogglePin(LedA1_GPIO_Port, LedA1_Pin);

	  HAL_Delay(500);

	  while(1)
	  {

	  switch(modo)
	  {

	  //---------------------
	  // MODO 0 - ESPERA
	  //---------------------
	  case 0:

	  ContadorA = 0;
	  ContadorB = 0;

	  break;


	  //---------------------
	  // MODO 1 - CUENTA 5→1
	  //---------------------
	  case 1:
	// Apagar todos los leds
	  HAL_GPIO_WritePin(LedA1_GPIO_Port, LedA1_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedA2_GPIO_Port, LedA2_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedA3_GPIO_Port, LedA3_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedA4_GPIO_Port, LedA4_Pin, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(LedB1_GPIO_Port, LedB1_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedB2_GPIO_Port, LedB2_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedB3_GPIO_Port, LedB3_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedB4_GPIO_Port, LedB4_Pin, GPIO_PIN_RESET);

	  // -------- 5 --------
	  HAL_GPIO_WritePin(SEGa_GPIO_Port, SEGa_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGb_GPIO_Port, SEGb_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGc_GPIO_Port, SEGc_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGd_GPIO_Port, SEGd_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGe_GPIO_Port, SEGe_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGf_GPIO_Port, SEGf_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGg_GPIO_Port, SEGg_Pin, GPIO_PIN_SET);

	  HAL_Delay(1000);

	  // -------- 4 --------
	  HAL_GPIO_WritePin(SEGa_GPIO_Port, SEGa_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGb_GPIO_Port, SEGb_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGc_GPIO_Port, SEGc_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGd_GPIO_Port, SEGd_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGe_GPIO_Port, SEGe_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGf_GPIO_Port, SEGf_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGg_GPIO_Port, SEGg_Pin, GPIO_PIN_SET);

	  HAL_Delay(1000);

	  // -------- 3 --------
	  HAL_GPIO_WritePin(SEGa_GPIO_Port, SEGa_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGb_GPIO_Port, SEGb_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGc_GPIO_Port, SEGc_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGd_GPIO_Port, SEGd_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGe_GPIO_Port, SEGe_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGf_GPIO_Port, SEGf_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGg_GPIO_Port, SEGg_Pin, GPIO_PIN_SET);

	  HAL_Delay(1000);

	  // -------- 2 --------
	  HAL_GPIO_WritePin(SEGa_GPIO_Port, SEGa_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGb_GPIO_Port, SEGb_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGc_GPIO_Port, SEGc_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGd_GPIO_Port, SEGd_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGe_GPIO_Port, SEGe_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGf_GPIO_Port, SEGf_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGg_GPIO_Port, SEGg_Pin, GPIO_PIN_SET);

	  HAL_Delay(1000);

	  // -------- 1 --------
	  HAL_GPIO_WritePin(SEGa_GPIO_Port, SEGa_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGb_GPIO_Port, SEGb_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGc_GPIO_Port, SEGc_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGd_GPIO_Port, SEGd_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGe_GPIO_Port, SEGe_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGf_GPIO_Port, SEGf_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGg_GPIO_Port, SEGg_Pin, GPIO_PIN_RESET);

	  HAL_Delay(1000);

	  modo = 2;

	  break;


	  //---------------------
	  // MODO 2 - JUEGO
	  //---------------------
	  case 2:

	  // Mostrar avance A
	  if(ContadorA >= 1) HAL_GPIO_WritePin(LedA1_GPIO_Port, LedA1_Pin, GPIO_PIN_SET);
	  if(ContadorA >= 2) HAL_GPIO_WritePin(LedA2_GPIO_Port, LedA2_Pin, GPIO_PIN_SET);
	  if(ContadorA >= 3) HAL_GPIO_WritePin(LedA3_GPIO_Port, LedA3_Pin, GPIO_PIN_SET);
	  if(ContadorA >= 4) HAL_GPIO_WritePin(LedA4_GPIO_Port, LedA4_Pin, GPIO_PIN_SET);

	  // Mostrar avance B
	  if(ContadorB >= 1) HAL_GPIO_WritePin(LedB1_GPIO_Port, LedB1_Pin, GPIO_PIN_SET);
	  if(ContadorB >= 2) HAL_GPIO_WritePin(LedB2_GPIO_Port, LedB2_Pin, GPIO_PIN_SET);
	  if(ContadorB >= 3) HAL_GPIO_WritePin(LedB3_GPIO_Port, LedB3_Pin, GPIO_PIN_SET);
	  if(ContadorB >= 4) HAL_GPIO_WritePin(LedB4_GPIO_Port, LedB4_Pin, GPIO_PIN_SET);

	  // Verificar ganador
	  if(ContadorA == 4 || ContadorB == 4)
	  {
	      modo = 3;
	  }

	  break;


	  //---------------------
	  // MODO 3 - GANADOR
	  //---------------------
	  case 3:

	  if(ContadorA == 4)
	  {

	  // apagar B
	  HAL_GPIO_WritePin(LedB1_GPIO_Port, LedB1_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedB2_GPIO_Port, LedB2_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedB3_GPIO_Port, LedB3_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedB4_GPIO_Port, LedB4_Pin, GPIO_PIN_RESET);

	  // encender A
	  HAL_GPIO_WritePin(LedA1_GPIO_Port, LedA1_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(LedA2_GPIO_Port, LedA2_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(LedA3_GPIO_Port, LedA3_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(LedA4_GPIO_Port, LedA4_Pin, GPIO_PIN_SET);

	  // mostrar 1
	  HAL_GPIO_WritePin(SEGa_GPIO_Port, SEGa_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGb_GPIO_Port, SEGb_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGc_GPIO_Port, SEGc_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGd_GPIO_Port, SEGd_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGe_GPIO_Port, SEGe_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGf_GPIO_Port, SEGf_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGg_GPIO_Port, SEGg_Pin, GPIO_PIN_RESET);

	  }

	  else if(ContadorB == 4)
	  {

	  HAL_GPIO_WritePin(LedA1_GPIO_Port, LedA1_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedA2_GPIO_Port, LedA2_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedA3_GPIO_Port, LedA3_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(LedA4_GPIO_Port, LedA4_Pin, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(LedB1_GPIO_Port, LedB1_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(LedB2_GPIO_Port, LedB2_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(LedB3_GPIO_Port, LedB3_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(LedB4_GPIO_Port, LedB4_Pin, GPIO_PIN_SET);

	  // mostrar 2
	  HAL_GPIO_WritePin(SEGa_GPIO_Port, SEGa_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGb_GPIO_Port, SEGb_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGc_GPIO_Port, SEGc_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGd_GPIO_Port, SEGd_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGe_GPIO_Port, SEGe_Pin, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(SEGf_GPIO_Port, SEGf_Pin, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(SEGg_GPIO_Port, SEGg_Pin, GPIO_PIN_SET);

	  }

	  HAL_Delay(3000);

	  modo = 0;

	  break;

	  }

	  }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, SEGd_Pin|SEGc_Pin|SEGb_Pin|LedB2_Pin
                          |LedB3_Pin|LedA1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LedB1_Pin|LedA2_Pin|LedA4_Pin|LedA3_Pin
                          |SEGa_Pin|SEGf_Pin|SEGe_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LedB4_Pin|SEGg_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : BTN1_Pin BTN2_Pin */
  GPIO_InitStruct.Pin = BTN1_Pin|BTN2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : BTN3_Pin */
  GPIO_InitStruct.Pin = BTN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(BTN3_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : SEGd_Pin SEGc_Pin SEGb_Pin LedB2_Pin
                           LedB3_Pin LedA1_Pin */
  GPIO_InitStruct.Pin = SEGd_Pin|SEGc_Pin|SEGb_Pin|LedB2_Pin
                          |LedB3_Pin|LedA1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LedB1_Pin LedA2_Pin LedA4_Pin LedA3_Pin
                           SEGa_Pin SEGf_Pin SEGe_Pin */
  GPIO_InitStruct.Pin = LedB1_Pin|LedA2_Pin|LedA4_Pin|LedA3_Pin
                          |SEGa_Pin|SEGf_Pin|SEGe_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : LedB4_Pin SEGg_Pin */
  GPIO_InitStruct.Pin = LedB4_Pin|SEGg_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

  HAL_NVIC_SetPriority(EXTI1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	if(GPIO_Pin == BTN1_Pin){
		if(modo == 0){
			modo = 1;
		}
	}else if(GPIO_Pin == BTN2_Pin){
		if(modo==2){
		ContadorA++;}
	}else if(GPIO_Pin == BTN3_Pin){
		if(modo==2){
		ContadorB++;}

	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
