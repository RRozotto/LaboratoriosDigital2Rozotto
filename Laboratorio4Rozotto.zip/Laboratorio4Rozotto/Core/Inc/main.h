/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define B1_Pin GPIO_PIN_13
#define B1_GPIO_Port GPIOC
#define BTN1_Pin GPIO_PIN_0
#define BTN1_GPIO_Port GPIOC
#define BTN1_EXTI_IRQn EXTI0_IRQn
#define BTN2_Pin GPIO_PIN_1
#define BTN2_GPIO_Port GPIOC
#define BTN2_EXTI_IRQn EXTI1_IRQn
#define USART_TX_Pin GPIO_PIN_2
#define USART_TX_GPIO_Port GPIOA
#define USART_RX_Pin GPIO_PIN_3
#define USART_RX_GPIO_Port GPIOA
#define BTN3_Pin GPIO_PIN_4
#define BTN3_GPIO_Port GPIOA
#define BTN3_EXTI_IRQn EXTI4_IRQn
#define SEGd_Pin GPIO_PIN_5
#define SEGd_GPIO_Port GPIOA
#define SEGc_Pin GPIO_PIN_6
#define SEGc_GPIO_Port GPIOA
#define SEGb_Pin GPIO_PIN_7
#define SEGb_GPIO_Port GPIOA
#define LedB1_Pin GPIO_PIN_10
#define LedB1_GPIO_Port GPIOB
#define LedB4_Pin GPIO_PIN_7
#define LedB4_GPIO_Port GPIOC
#define SEGg_Pin GPIO_PIN_9
#define SEGg_GPIO_Port GPIOC
#define LedB2_Pin GPIO_PIN_8
#define LedB2_GPIO_Port GPIOA
#define LedB3_Pin GPIO_PIN_9
#define LedB3_GPIO_Port GPIOA
#define LedA1_Pin GPIO_PIN_10
#define LedA1_GPIO_Port GPIOA
#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA
#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA
#define LedA2_Pin GPIO_PIN_3
#define LedA2_GPIO_Port GPIOB
#define LedA4_Pin GPIO_PIN_4
#define LedA4_GPIO_Port GPIOB
#define LedA3_Pin GPIO_PIN_5
#define LedA3_GPIO_Port GPIOB
#define SEGa_Pin GPIO_PIN_6
#define SEGa_GPIO_Port GPIOB
#define SEGf_Pin GPIO_PIN_8
#define SEGf_GPIO_Port GPIOB
#define SEGe_Pin GPIO_PIN_9
#define SEGe_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
